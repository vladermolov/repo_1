# Curso Objetos con JS
Curso de Barcelona Activa, Introducción a la Programación 2 (Objetos) en JS

## Links de documentación 

https://www.w3schools.com/js/default.asp 

https://developer.mozilla.org/es/docs/Web/JavaScript 

